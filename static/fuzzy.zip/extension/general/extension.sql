-- Fuzzy Extension for PostgreSQL
-- Copyright Krzysztof Miemiec 2018
-- Based on code of Bartosz Dziedzic & Bożena Małysiak-Mrozek

\echo Use "CREATE EXTENSION fuzzy" to load this file. \quit
